import {Component} from '@angular/core';

@Component({
  
      selector: 'app',
      template: '<model-form></model-form>',
      // styleUrls: ['app.component.css']

})

export class AppComponent {
    

   }





