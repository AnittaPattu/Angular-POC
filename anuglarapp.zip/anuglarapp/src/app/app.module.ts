import {NgModule} from '@angular/core';
import {HttpModule} from '@angular/http';
import {BrowserModule} from '@angular/platform-browser';
import { FormsModule,ReactiveFormsModule,Validators} from '@angular/forms';
import {ModelFormComponent} from './app.model.form';
import {AppComponent} from './app.component';




@NgModule({
      
      imports:[BrowserModule,FormsModule,ReactiveFormsModule,HttpModule],
      declarations:[AppComponent,ModelFormComponent],
      bootstrap: [AppComponent]

})

export class AppModule{



}