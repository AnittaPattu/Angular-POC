
export interface Location{

    name:string;
    age:number;
	
}