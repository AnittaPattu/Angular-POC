import {OnInit,Component,Pipe,NgModule} from '@angular/core';
import {FormGroup,FormControl,ReactiveFormsModule,FormsModule,Validators,FormBuilder} from '@angular/forms';
import {BrowserModule} from '@angular/platform-browser';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';


 @Component({

           selector:"model-form",
           templateUrl:"app.component.html"
    })

export class ModelFormComponent implements OnInit
{

    message : string = "angular"
    date   = new Date();
    us: number = 0.12345;
  	ind: number = 1.09876;
   
    langs: string[] = ['English' , 'French' , 'Hindi' , 'Tamil'];
    
    myform  : FormGroup;    
    uname   : FormControl;
    password : FormControl;
    email    : FormControl;
    language : FormControl;
    

  ngOnInit(){
          
       this.createFormControls();
       this.createFormGroup();

  }

  createFormControls(){

           this.uname     = new FormControl('', [Validators.required,Validators.minLength(8)]);
           this.password  = new FormControl('', [Validators.required,Validators.minLength(8)]);
           this.email     = new FormControl('', [Validators.required,Validators.minLength(8)]);
           this.language  = new FormControl('', [Validators.required,Validators.minLength(8)]);
           
  }

  createFormGroup(){

        this.myform = new FormGroup(
           {
            uname    : this.uname,
            password : this.password,
            email    : this.email, 
            language : this.language
          });

}

onSubmit(){


 
   this.myform.reset();


}

  

}