# Photo Blog

1. Clone the repository
2. Run `npm install`
3. Start the server `npm run serve`